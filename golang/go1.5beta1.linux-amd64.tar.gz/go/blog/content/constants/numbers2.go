// +build OMIT

package main

import "fmt"

func main() {
	// START OMIT
	var f = 'a' * 1.5
	fmt.Println(f)
	// STOP OMIT
}
