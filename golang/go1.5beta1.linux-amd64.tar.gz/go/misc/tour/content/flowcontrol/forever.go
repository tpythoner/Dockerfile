// +build OMIT

package main

func main() {
	for {
	}
}
